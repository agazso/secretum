
To work with TDD:

`chokidar "**/*.ts" "*.json" -c "npm test"`

Links:

* http://dedis.cs.yale.edu/dissent/
* https://github.com/dedis/Dissent
* https://diracdeltas.github.io/blog/rate-limiting-anonymous-accounts/
* https://en.wikipedia.org/wiki/Blind_signature
* http://people.csail.mit.edu/devadas/pubs/riffle.pdf
* https://news.ycombinator.com/item?id=12635848

